O0003 (DRILL THROUGH HOLES - 5/16")
(0.3125" TWIST DRILL - T03)
(1.000" STOCK, THROUGH HOLES)
(G54 X0=LEFT Y0=FRONT Z0=TOP)

G20 G40 G49 G80 G90 G94 G17       (SAFE STARTUP)
T03 M6                             (LOAD 5/16" TWIST DRILL)
G0 G54 X0 Y0                       (RAPID TO STOCK CORNER)
S3000 M3                           (SPINDLE CW @ 3000 RPM)
G43 H03 Z0.250                     (TOOL LENGTH OFFSET, CLEARANCE)

(--- DRILL HOLE 1: X1.000 Y1.000 ---)
G0 X1.000 Y1.000                   (RAPID TO HOLE 1 XY)
G98 G81 Z-1.050 R0.100 F7.0        (G81 CYCLE: DEPTH 1.050", R-PLANE 0.100")

(--- DRILL HOLE 2: X5.000 Y1.000 ---)
X5.000                             (DRILL HOLE 2 - SAME Z/R/F)

(--- DRILL HOLE 3: X1.000 Y3.000 ---)
X1.000 Y3.000                      (DRILL HOLE 3)

(--- DRILL HOLE 4: X5.000 Y3.000 ---)
X5.000                             (DRILL HOLE 4)

(--- CANCEL CANNED CYCLE ---)
G80                                (CANCEL G81)
G0 Z0.250                          (RETRACT TO CLEARANCE)

(--- END PROGRAM ---)
G53 G0 Z0                          (RAPID TO MACHINE Z-ZERO)
M5                                 (SPINDLE STOP)
M30                                (PROGRAM END)
%
