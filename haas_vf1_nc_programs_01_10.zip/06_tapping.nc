O0006 (TAPPING - 1/4-20 UNC)
(1/4-20 TAP - T06)
(PRE-DRILLED 0.201", THREAD DEPTH 0.500")
(RIGID TAPPING - G84)
(G54 X0=LEFT Y0=FRONT Z0=TOP)

G20 G40 G49 G80 G90 G94 G17       (SAFE STARTUP)
T06 M6                             (LOAD 1/4-20 TAP)
G0 G54 X0 Y0                       (RAPID TO STOCK CORNER)
S500 M3                            (SPINDLE CW @ 500 RPM)
G43 H06 Z0.250                     (TOOL LENGTH OFFSET, CLEARANCE)

(--- TAP HOLE: X3.000 Y2.000 ---)
G0 X3.000 Y2.000                   (RAPID TO HOLE XY)
G98 G84 Z-0.500 R0.100 F25.0       (G84 RIGID TAP: DEPTH 0.500", FEED 25.0 IPM)
                                    (FEED = RPM X PITCH = 500 X 0.050 = 25.0)

(--- CANCEL CANNED CYCLE ---)
G80                                (CANCEL G84)
G0 Z0.250                          (RETRACT TO CLEARANCE)

(--- END PROGRAM ---)
G53 G0 Z0                          (RAPID TO MACHINE Z-ZERO)
M5                                 (SPINDLE STOP)
M30                                (PROGRAM END)
%
