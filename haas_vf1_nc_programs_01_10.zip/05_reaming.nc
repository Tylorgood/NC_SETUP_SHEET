O0005 (REAMING - 5/16" HOLE)
(0.3125" HAND REAMER - T05)
(PRE-DRILLED 0.305", LEAVE 0.007" STOCK)
(1.000" STOCK, THROUGH HOLE)
(G54 X0=LEFT Y0=FRONT Z0=TOP)

G20 G40 G49 G80 G90 G94 G17       (SAFE STARTUP)
T05 M6                             (LOAD 5/16" REAMER)
G0 G54 X0 Y0                       (RAPID TO STOCK CORNER)
S800 M3                            (SPINDLE CW @ 800 RPM - SLOW FOR REAMER)
G43 H05 Z0.250                     (TOOL LENGTH OFFSET, CLEARANCE)

(--- REAM HOLE: X3.000 Y2.000 ---)
G0 X3.000 Y2.000                   (RAPID TO HOLE XY)
G0 Z0.100                          (RAPID TO CLEARANCE ABOVE SURFACE)
G01 Z-1.050 F4.0                   (FEED THROUGH HOLE AT 4.0 IPM)
G0 Z0.250                          (RETRACT TO CLEARANCE)

(--- CANCEL TOOL OFFSET ---)
G49                                (CANCEL TOOL LENGTH OFFSET)

(--- END PROGRAM ---)
G53 G0 Z0                          (RAPID TO MACHINE Z-ZERO)
M5                                 (SPINDLE STOP)
M30                                (PROGRAM END)
%
