O0001 (FACING - 6061 ALUMINUM)
(1.000" 4-FLUTE END MILL - T01)
(ROUGH 0.020", FINISH 0.010")
(6.000 X 4.000 X 1.500 STOCK)
(G54 X0=LEFT Y0=FRONT Z0=TOP)

G20 G40 G49 G80 G90 G94 G17       (SAFE STARTUP - INCH, CANCELS, ABSOLUTE)
T01 M6                             (LOAD 1.000" END MILL)
G0 G54 X0 Y0                       (RAPID TO STOCK CORNER - XY)
S3000 M3                           (SPINDLE CW @ 3000 RPM)
G43 H01 Z0.250 D01                 (TOOL LENGTH OFFSET, CLEARANCE HEIGHT)
G54 Z0.100                         (MOVE TO SAFE START Z)

(--- ROUGHING PASS 1 ---)
G0 Z0.100                          (RAPID TO CLEARANCE ABOVE STOCK)
X0.5 Y0                            (OFFSET 0.5" FROM EDGE FOR ENTRY)
G01 Z-0.020 F5.0                   (PLUNGE AT FEEDRATE)
X5.5 F12.0                         (FACE LEFT-TO-RIGHT, 0.800" STEP)
Y4.0                               (FACE FRONT-TO-BACK)
X0.5                               (FACE RIGHT-TO-LEFT)
Y0                                 (FACE BACK-TO-FRONT)
X5.5                               (SECOND ROW LEFT-TO-RIGHT)
Y4.0                               (FACE FRONT-TO-BACK)
X0.5                               (FACE RIGHT-TO-LEFT)

(--- FINISHING PASS ---)
G0 Z0.100                          (RETRACT TO CLEARANCE)
X0.5 Y0                            (RETURN TO START POSITION)
G01 Z-0.030 F5.0                   (PLUNGE TO FINAL DEPTH - 0.030" TOTAL)
X5.5 F10.0                         (FINISH CUT - REDUCED FEED)
Y4.0
X0.5
Y0
X5.5
Y4.0
X0.5

(--- END PROGRAM ---)
G0 Z0.250                          (RETRACT TO CLEARANCE)
G53 G0 Z0                          (RAPID TO MACHINE Z-ZERO - HOME)
M5                                 (SPINDLE STOP)
M30                                (PROGRAM END + RESET)
%
