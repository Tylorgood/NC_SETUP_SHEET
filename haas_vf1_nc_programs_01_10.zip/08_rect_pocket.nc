O0008 (RECTANGULAR POCKET - 6061 ALUMINUM)
(0.500" 4-FLUTE END MILL - T08)
(POCKET: 3.000" X 2.000" X 0.300" DEEP)
(RASTER ROUGH + PERIMETER FINISH WITH G41)
(G54 X0=LEFT Y0=FRONT Z0=TOP)
(POCKET EDGES: X1.5 Y1.0 TO X4.5 Y3.0)

G20 G40 G49 G80 G90 G94 G17       (SAFE STARTUP - INCH, CANCELS, ABSOLUTE)
T08 M6                             (LOAD 0.500" 4-FLUTE END MILL)
G0 G54 X3.0 Y2.0                   (RAPID TO POCKET CENTER - XY START)
S6000 M3                           (SPINDLE CW @ 6000 RPM)
G43 H08 Z0.250 D08                 (TOOL LENGTH OFFSET, CLEARANCE HEIGHT)

(--- ROUGHING PASS 1 - DEPTH 0.150 ---)
G0 Z0.100                          (RAPID TO CLEARANCE ABOVE STOCK)
G01 Z-0.150 F5.0                   (PLUNGE TO ROUGH DEPTH - 0.150")

(ROW 1 - Y1.265, LEFT TO RIGHT)
G0 X1.765 Y1.265 F15.0             (RAPID TO ROW 1 START - INSIDE POCKET)
X4.235                             (CUT ROW 1 LEFT-TO-RIGHT)

(ROW 2 - Y1.615, RIGHT TO LEFT)
Y1.615                             (STEP OVER 0.350")
X1.765                             (CUT ROW 2 RIGHT-TO-LEFT)

(ROW 3 - Y1.965, LEFT TO RIGHT)
Y1.965                             (STEP OVER 0.350")
X4.235                             (CUT ROW 3 LEFT-TO-RIGHT)

(ROW 4 - Y2.315, RIGHT TO LEFT)
Y2.315                             (STEP OVER 0.350")
X1.765                             (CUT ROW 4 RIGHT-TO-LEFT)

(ROW 5 - Y2.665, LEFT TO RIGHT)
Y2.665                             (STEP OVER 0.350")
X4.235                             (CUT ROW 5 LEFT-TO-RIGHT)

(ROW 6 - Y3.015, RIGHT TO LEFT - FINAL ROW)
Y3.015                             (STEP TO FINAL ROW - PAST POCKET EDGE)
X1.765                             (CUT ROW 6 RIGHT-TO-LEFT)

(--- ROUGHING PASS 2 - DEPTH 0.300 ---)
G0 X3.0 Y2.0                       (RAPID BACK TO POCKET CENTER)
G01 Z-0.300 F5.0                   (PLUNGE TO FINAL ROUGH DEPTH - 0.300")

(ROW 1 - Y1.265, LEFT TO RIGHT)
G0 X1.765 Y1.265 F15.0             (RAPID TO ROW 1 START)
X4.235                             (CUT ROW 1 LEFT-TO-RIGHT)

(ROW 2 - Y1.615, RIGHT TO LEFT)
Y1.615
X1.765

(ROW 3 - Y1.965, LEFT TO RIGHT)
Y1.965
X4.235

(ROW 4 - Y2.315, RIGHT TO LEFT)
Y2.315
X1.765

(ROW 5 - Y2.665, LEFT TO RIGHT)
Y2.665
X4.235

(ROW 6 - Y3.015, RIGHT TO LEFT - FINAL ROW)
Y3.015
X1.765

(--- FINISH PASS - PERIMETER WITH G41 ---)
G0 Z0.100                          (RETRACT TO CLEARANCE)
G0 X1.350 Y2.0                     (RAPID TO LEAD-IN POSITION - LEFT OF POCKET)
G41 D08 G01 X1.500 Y2.0 F12.0      (TURN ON G41 LEFT COMP - LEAD-IN TO POCKET EDGE)
                                           (D08 = 0.250" TOOL RADIUS + WEAR OFFSET)
                                           (TOOL CENTER SHIFTS LEFT BY D08 VALUE)
                                           (0.250" radius leaves 0.015" on wall)
Z-0.300 F5.0                       (PLUNGE TO FINISH DEPTH)

Y3.015                             (CUT LEFT WALL UP - PAST CORNER BY 0.015")
X4.500 Y3.000                      (CUT TOP-RIGHT CORNER)
X4.500                             (CUT RIGHT WALL DOWN)
Y1.000                             (CUT BOTTOM-RIGHT CORNER)
X1.500                             (CUT BOTTOM WALL LEFT)
Y1.000                             (CUT BOTTOM-LEFT CORNER)
X1.365 Y2.0                        (LEAD-OUT MOVE - BACK TO LEAD-IN LINE)

G40 G01 X1.500                     (CANCEL COMPENSATION, RETURN TO POCKET EDGE)
G0 Z0.250                          (RETRACT TO CLEARANCE)
G53 G0 Z0                          (RAPID TO MACHINE Z-HOME)
M5                                 (SPINDLE STOP)
M30                                (PROGRAM END + RESET)
%
