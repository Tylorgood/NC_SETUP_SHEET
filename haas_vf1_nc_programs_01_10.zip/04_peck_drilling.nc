O0004 (PECK DRILL - 5/16" DEEP HOLES)
(0.3125" TWIST DRILL - T04)
(1.500" STOCK, 1.200" DEEP HOLES)
(PECK Q=0.250", DWELL 0.2 SEC)
(G54 X0=LEFT Y0=FRONT Z0=TOP)

G20 G40 G49 G80 G90 G94 G17       (SAFE STARTUP)
T04 M6                             (LOAD 5/16" TWIST DRILL)
G0 G54 X0 Y0                       (RAPID TO STOCK CORNER)
S3000 M3                           (SPINDLE CW @ 3000 RPM)
G43 H04 Z0.250                     (TOOL LENGTH OFFSET, CLEARANCE)

(--- PECK DRILL HOLE 1: X2.000 Y1.500 ---)
G0 X2.000 Y1.500                   (RAPID TO HOLE 1 XY)
G98 G83 Z-1.200 R0.100 Q0.250 P200 F7.0
                                    (G83 PECK: DEPTH 1.200", PECK 0.250",
                                     DWELL 0.2 SEC AT BOTTOM, R-PLANE 0.100")

(--- PECK DRILL HOLE 2: X4.000 Y2.500 ---)
X4.000 Y2.500                      (PECK DRILL HOLE 2 - SAME PARAMETERS)

(--- CANCEL CANNED CYCLE ---)
G80                                (CANCEL G83)
G0 Z0.250                          (RETRACT TO CLEARANCE)

(--- END PROGRAM ---)
G53 G0 Z0                          (RAPID TO MACHINE Z-ZERO)
M5                                 (SPINDLE STOP)
M30                                (PROGRAM END)
%
